(**********************************************************************************************************************************************************************************************************************************)
(******************************************************************************************************** GLOBAL VARIABLES ********************************************************************************************************)
(**********************************************************************************************************************************************************************************************************************************)

    (* Indicates if we see the steps. Setting to false is faster *)
    let viewSteps = true;;

(**********************************************************************************************************************************************************************************************************************************)
(************************************************************************************************************ FUNCTIONS ***********************************************************************************************************)
(**********************************************************************************************************************************************************************************************************************************)

    (* Converts x/y into l/c *)
    let toGraphicsCoordinates imageArray l c =
        
        (c, Array.length imageArray - 1 - l)
        
    ;;

(**********************************************************************************************************************************************************************************************************************************)

    (* Loads the image file *)
    let loadImage fileName =
        
        let image = Sdlloader.load_image fileName in
        let imageInfo = Sdlvideo.surface_info image in
        let imageArray = Array.make_matrix imageInfo.h imageInfo.w Graphics.white in
        for l = 0 to imageInfo.h - 1
        do
            for c = 0 to imageInfo.w - 1
            do
                let pixelValue = Sdlvideo.get_pixel image c l in
                if pixelValue <= Int32.zero && pixelValue <> Int32.minus_one
                then
                    imageArray.(l).(c) <- Graphics.black
            done
        done;
        imageArray
        
    ;;

(**********************************************************************************************************************************************************************************************************************************)

    (* Fills the graphics with the original image, colors the nodes, and enlarges the edges *)
    let initGraphics imageArray nodes =

        Graphics.open_graph (" " ^ (string_of_int (Array.length imageArray.(0))) ^ "x" ^ (string_of_int (Array.length imageArray)) ^ "+0-0");
        Graphics.display_mode viewSteps;
        Graphics.set_color Graphics.black;
        for l = 0 to Array.length imageArray - 1
        do
            for c = 0 to Array.length imageArray.(0) - 1
            do
                if imageArray.(l).(c) = 0
                then
                (
                    let (lGraphics, cGraphics) = toGraphicsCoordinates imageArray l c in
                    Graphics.plot lGraphics cGraphics
                )
            done
        done;
        Graphics.set_color Graphics.red;
        let nodesAsArray = Array.of_list nodes in
        for i = 0 to Array.length nodesAsArray - 1
        do
            let (lGraphics, cGraphics) = toGraphicsCoordinates imageArray (fst nodesAsArray.(i)) (snd nodesAsArray.(i)) in
            Graphics.fill_circle lGraphics cGraphics 6
        done;
        for l = 1 to Array.length imageArray - 2
        do
            for c = 1 to Array.length imageArray.(0) - 2
            do
                let pixelColor = imageArray.(l).(c) in
                if pixelColor = 0
                then
                (
                    let (lGraphics, cGraphics) = toGraphicsCoordinates imageArray l c in
                    Graphics.fill_circle lGraphics cGraphics 1
                )
            done
        done;
        let initialGraphics = Array.make_matrix (Array.length imageArray) (Array.length imageArray.(0)) 0 in
        for l = 0 to Array.length imageArray - 1
        do
            for c = 0 to Array.length imageArray.(0) - 1
            do
                let (lGraphics, cGraphics) = toGraphicsCoordinates imageArray l c in
                initialGraphics.(l).(c) <- Graphics.point_color lGraphics cGraphics
            done
        done;
        initialGraphics
        
    ;;

(**********************************************************************************************************************************************************************************************************************************)

    (* Restores the graphics with the original image *)
    let restoreGraphics initialGraphics =
        
        for l = 0 to Array.length initialGraphics - 1
        do
            for c = 0 to Array.length initialGraphics.(0) - 1
            do
                Graphics.set_color initialGraphics.(l).(c);
                let (lGraphics, cGraphics) = toGraphicsCoordinates initialGraphics l c in
                Graphics.plot lGraphics cGraphics
            done
        done
        
    ;;

(**********************************************************************************************************************************************************************************************************************************)
    
    (* Determines the coordinates of the nodes *)
    let findNodes imageArray nodeModelArray =
        
        let nodes = ref [] in
        for l = 0 to Array.length imageArray - Array.length nodeModelArray - 1
        do
            for c = 0 to Array.length imageArray.(0) - Array.length nodeModelArray.(0) - 1
            do
                let canBeNode = ref true in
                for ll = 0 to Array.length nodeModelArray - 1
                do
                    if !canBeNode
                    then
                    (
                        for cc = 0 to Array.length nodeModelArray.(0) - 1
                        do
                            if !canBeNode
                            then
                            (
                                if imageArray.(l + ll).(c + cc) = Graphics.white && nodeModelArray.(ll).(cc) = Graphics.black
                                then
                                    canBeNode := false
                            )
                        done
                    )
                done;
                if !canBeNode
                then
                (
                    nodes := (l + (int_of_float (ceil ((float_of_int (Array.length nodeModelArray)) /. 2.0))), c + (int_of_float (ceil ((float_of_int (Array.length nodeModelArray.(0))) /. 2.0)))) :: !nodes;
                )
            done
        done;
        !nodes
        
    ;;

(**********************************************************************************************************************************************************************************************************************************)
    
    (* Counts the number of red pixels in the window defined by the 2 points *)
    let countRedPixelsInGraphics initialGraphics node1 node2 =
        
        let lMin = min (fst node1) (fst node2) in
        let lMax = max (fst node1) (fst node2) in
        let cMin = min (snd node1) (snd node2) in
        let cMax = max (snd node1) (snd node2) in
        let count = ref 0 in
        for l = lMin to lMax
        do
            for c = cMin to cMax
            do
                let (lGraphics, cGraphics) = toGraphicsCoordinates initialGraphics l c in
                let pixelColor = Graphics.point_color lGraphics cGraphics in
                if pixelColor = Graphics.red
                then
                    incr count
            done
        done;
        !count
        
    ;;

(**********************************************************************************************************************************************************************************************************************************)
    
    (* Adds an edge to the picture *)
    let addEdge initialGraphics node1 node2 color =
        
        Graphics.set_color color;
        let (lGraphics1, cGraphics1) = toGraphicsCoordinates initialGraphics (fst node1) (snd node1) in
        let (lGraphics2, cGraphics2) = toGraphicsCoordinates initialGraphics (fst node2) (snd node2) in
        Graphics.moveto lGraphics1 cGraphics1;
        Graphics.lineto lGraphics2 cGraphics2
        
    ;;

(**********************************************************************************************************************************************************************************************************************************)

    (* Returns the adjacency matrix of the graph (a list of lists would be more efficient but we don't really care here) *)
    let determineAdjacencyMatrix initialGraphics nodes =
        
        let adjacencyMatrix = Array.make_matrix (List.length nodes) (List.length nodes) 0 in
        let nodesAsArray = Array.of_list nodes in
        for i = 0 to List.length nodes - 1
        do
            for j = i + 1 to List.length nodes - 1
            do
                let nbRedPixelsBefore = countRedPixelsInGraphics initialGraphics nodesAsArray.(i) nodesAsArray.(j) in
                addEdge initialGraphics nodesAsArray.(i) nodesAsArray.(j) Graphics.red;
                let nbRedPixelsAfter = countRedPixelsInGraphics initialGraphics nodesAsArray.(i) nodesAsArray.(j) in
                if nbRedPixelsBefore - nbRedPixelsAfter = 0
                then
                (
                    adjacencyMatrix.(i).(j) <- 1;
                    adjacencyMatrix.(j).(i) <- 1
                )
                else
                    restoreGraphics initialGraphics
            done
        done;
        restoreGraphics initialGraphics;
        adjacencyMatrix
        
    ;;

(**********************************************************************************************************************************************************************************************************************************)

    (* Display the found graph *)
    let showGraph initialGraphics nodes adjacencyMatrix =
        
        Graphics.set_line_width 3;
        let nodesAsArray = Array.of_list nodes in
        for i = 0 to Array.length adjacencyMatrix - 1
        do
            for j = i + 1 to Array.length adjacencyMatrix - 1
            do
                if adjacencyMatrix.(i).(j) = 1
                then
                    addEdge initialGraphics nodesAsArray.(i) nodesAsArray.(j) Graphics.blue
            done
        done
        
    ;;

(**********************************************************************************************************************************************************************************************************************************)

    (* Returns the adjacency matrix of the graph (a list of lists would be more efficient but we don't really care here) *)
    let countTriangles adjacencyMatrix =
        
        let count = ref 0 in
        for i = 0 to Array.length adjacencyMatrix - 1
        do
            for j = i + 1 to Array.length adjacencyMatrix - 1
            do
                for k = j + 1 to Array.length adjacencyMatrix - 1
                do
                    if adjacencyMatrix.(i).(j) = 1 && adjacencyMatrix.(i).(k) = 1 && adjacencyMatrix.(j).(k) = 1
                    then
                        incr count
                done
            done
        done;
        !count
        
    ;;

(**********************************************************************************************************************************************************************************************************************************)
(************************************************************************************************************ CONTROLS ************************************************************************************************************)
(**********************************************************************************************************************************************************************************************************************************)

    (* We check that there are enough arguments *)
    if Array.length Sys.argv <> 3
    then
        failwith ("Usage: ./code <image.png> <nodeModel.png>")
    ;;

(**********************************************************************************************************************************************************************************************************************************)

    (* We check that the image exists *)
    if not (Sys.file_exists Sys.argv.(1))
    then
        failwith ("File " ^ Sys.argv.(1) ^ " doesn't exist")
    ;;

(**********************************************************************************************************************************************************************************************************************************)

    (* We check that the node model exists *)
    if not (Sys.file_exists Sys.argv.(2))
    then
        failwith ("File " ^ Sys.argv.(2) ^ " doesn't exist")
    ;;

(**********************************************************************************************************************************************************************************************************************************)

    (* We check that the image is a .png file *)
    if String.compare (String.sub Sys.argv.(1) (String.length Sys.argv.(1) - 4) 4) ".png" <> 0
    then
        failwith ("File " ^ Sys.argv.(1) ^ " is not a .png file")
    ;;

(**********************************************************************************************************************************************************************************************************************************)

    (* We check that the node model is a .png file *)
    if String.compare (String.sub Sys.argv.(2) (String.length Sys.argv.(2) - 4) 4) ".png" <> 0
    then
        failwith ("File " ^ Sys.argv.(2) ^ " is not a .png file")
    ;;

(**********************************************************************************************************************************************************************************************************************************)
(************************************************************************************************************* SCRIPT *************************************************************************************************************)
(**********************************************************************************************************************************************************************************************************************************)

    (* Computation *)
    let imageArray = loadImage Sys.argv.(1);;
    let nodeModelArray = loadImage Sys.argv.(2);;
    let nodes = findNodes imageArray nodeModelArray;;
    print_endline ("Nodes: " ^ (string_of_int (List.length nodes)));;
    let initialGraphics = initGraphics imageArray nodes;;
    let adjacencyMatrix = determineAdjacencyMatrix initialGraphics nodes;;
    showGraph initialGraphics nodes adjacencyMatrix;;
    let nbTriangles = countTriangles adjacencyMatrix;;
    print_endline ("Triangles: " ^ (string_of_int nbTriangles));;
    
    (* To continue displaying the graphics *)
    while true do () done;;
    
(**********************************************************************************************************************************************************************************************************************************)
(**********************************************************************************************************************************************************************************************************************************)