(**********************************************************************************************************************************************************************************************************************************)
(******************************************************************************************************** GLOBAL VARIABLES ********************************************************************************************************)
(**********************************************************************************************************************************************************************************************************************************)
    
    (* Text to decode *)
    let textToDecode = "nhjexd rz wfu gx l jmhcx aj afzeux htxa rzx jmhcx gx mxmx ehjllx gfze lx bjwxl gx affugfzzxxd j xe p xde zfju dj lh bhuejx xzejxux gx (gjw nfjd lx afdjzrd gx (rz axuehjz bxeje xzejxu nfjd (j nfjd rz hreux bxeje xzejxu nfjd lx ahuux gx p))) xde bhjux";;
    
(**********************************************************************************************************************************************************************************************************************************)

    (* Letters in French in decreasing order of frequency *)
    let sortedLettersInFrench = ['e'; 'a'; 's'; 'i'; 't'; 'n'; 'r'; 'u'; 'l'; 'o'; 'd'; 'c'; 'p'; 'm'; 'v'; 'q'; 'f'; 'b'; 'g'; 'h'; 'j'; 'x'; 'y'; 'z'; 'w'; 'k'];;

(**********************************************************************************************************************************************************************************************************************************)

    (* Mappings that we know (or at least assume) *)
    let assumedMappings = Hashtbl.create 26;;
    Hashtbl.add assumedMappings 'a' 'c';;
    Hashtbl.add assumedMappings 'c' 'g';;
    Hashtbl.add assumedMappings 'd' 's';;
    Hashtbl.add assumedMappings 'f' 'o';;
    Hashtbl.add assumedMappings 'g' 'd';;
    Hashtbl.add assumedMappings 'h' 'a';;
    Hashtbl.add assumedMappings 'j' 'i';;
    Hashtbl.add assumedMappings 'l' 'l';;
    Hashtbl.add assumedMappings 'm' 'm';;
    Hashtbl.add assumedMappings 'n' 'f';;
    Hashtbl.add assumedMappings 'p' 'j';;
    Hashtbl.add assumedMappings 'w' 'x';;

(**********************************************************************************************************************************************************************************************************************************)
    
    (* Maximum value for the 1st integer when determining the mask *)
    let x1Max = 100;;

(**********************************************************************************************************************************************************************************************************************************)
    
    (* Maximum value for the 2nd integer when determining the mask *)
    let x2Max = 100;;
    
(**********************************************************************************************************************************************************************************************************************************)
    
    (* Ratio of white pixels to accept the xored image *)
    let ratioOfWhitePixels = 0.6;;

(**********************************************************************************************************************************************************************************************************************************)
(************************************************************************************************************ FUNCTIONS ***********************************************************************************************************)
(**********************************************************************************************************************************************************************************************************************************)

    (* Converts x/y into l/c *)
    let toGraphicsCoordinates imageArray l c =
        
        (c, Array.length imageArray - 1 - l)
        
    ;;

(**********************************************************************************************************************************************************************************************************************************)

    (* Loads the image file *)
    let loadImage fileName =
        
        let image = Sdlloader.load_image fileName in
        let imageInfo = Sdlvideo.surface_info image in
        let imageArray = Array.make_matrix imageInfo.h imageInfo.w Graphics.white in
        for l = 0 to imageInfo.h - 1
        do
            for c = 0 to imageInfo.w - 1
            do
                let pixelValue = Sdlvideo.get_pixel image c l in
                if pixelValue <= Int32.zero && pixelValue <> Int32.minus_one
                then
                    imageArray.(l).(c) <- Graphics.black
            done
        done;
        imageArray
        
    ;;

(**********************************************************************************************************************************************************************************************************************************)

    (* Starts the graphics with the given image *)
    let showImage imageArray =

        Graphics.open_graph (" " ^ (string_of_int (Array.length imageArray.(0))) ^ "x" ^ (string_of_int (Array.length imageArray)) ^ "+0-0");
        Graphics.set_color Graphics.black;
        for l = 0 to Array.length imageArray - 1
        do
            for c = 0 to Array.length imageArray.(0) - 1
            do
                if imageArray.(l).(c) = Graphics.black
                then
                (
                    let (lGraphics, cGraphics) = toGraphicsCoordinates imageArray l c in
                    Graphics.plot lGraphics cGraphics
                )
            done
        done
        
    ;;

(**********************************************************************************************************************************************************************************************************************************)

    (* Applies the mask on the image  *)
    let xorImage imageArray mask =

        let resultImage = Array.make_matrix (Array.length imageArray) (Array.length imageArray.(0)) Graphics.black in
        for l = 0 to Array.length imageArray - 1
        do
            for c = 0 to Array.length imageArray.(0) - 1
            do
                if imageArray.(l).(c) = mask.(l).(c)
                then
                    resultImage.(l).(c) <- Graphics.white
            done
        done;
        resultImage
        
    ;;

(**********************************************************************************************************************************************************************************************************************************)

    (* Counts the number of white pixels in the graphics *)
    let countWhitePixels imageArray =
        
        let count = ref 0 in
        for l = 0 to Array.length imageArray - 1
        do
            for c = 0 to Array.length imageArray.(0) - 1
            do
                if imageArray.(l).(c) = Graphics.white
                then
                    incr count
            done
        done;
        !count
        
    ;;

(**********************************************************************************************************************************************************************************************************************************)

    (* Decodes the image by computing a mask using the indications in the encoded message *)
    let decodeImage imageArray =
        
        let continue = ref true in
        for x1 = 0 to x1Max
        do
            if !continue
            then
            (
                for x2 = 0 to x2Max
                do
                    if !continue
                    then
                    (
                        let maskArray = Array.make_matrix (Array.length imageArray) (Array.length imageArray.(0)) Graphics.white in
                        for l = 0 to Array.length imageArray - 1
                        do
                            for c = 0 to Array.length imageArray.(0) - 1
                            do
                                let result = int_of_float (10.0 *. cos((float_of_int x1) *. (float_of_int l) *. (float_of_int x2) *. (float_of_int c) ** 2.0)) in
                                if result mod 2 = 0
                                then
                                    maskArray.(l).(c) <- Graphics.black
                            done
                        done;
                        let resultImage = xorImage imageArray maskArray in
                        if float_of_int (countWhitePixels resultImage) /. float_of_int (Array.length resultImage * Array.length resultImage.(0)) > ratioOfWhitePixels
                        then
                        (
                            print_endline ("Original image found for x1=" ^ (string_of_int x1) ^ " and x2=" ^ (string_of_int x2));
                            showImage resultImage;
                            continue := false
                        )
                    )
                done
            )
        done
        
    ;;

(**********************************************************************************************************************************************************************************************************************************)

    (* Determines the frequencies of the letters in the text *)
    let determineFrequencies text =
        
        let totalCount = ref 0 in
        let lettersCountInText = Hashtbl.create 26 in
        String.iter
        (
            fun letter ->
            (
                if Char.code letter >= Char.code 'a' && Char.code letter <= Char.code 'z'
                then
                (
                    if not (Hashtbl.mem lettersCountInText letter)
                    then
                        Hashtbl.add lettersCountInText letter 0.0
                    ;
                    Hashtbl.replace lettersCountInText letter ((Hashtbl.find lettersCountInText letter) +. 1.0);
                    incr totalCount
                )
            )
        ) text;
        let frequenciesInText = Hashtbl.create 26 in
        Hashtbl.iter
        (
            fun letter letterCount ->
            (
                Hashtbl.add frequenciesInText letter (letterCount /. (float_of_int !totalCount))
            )
        ) lettersCountInText;
        frequenciesInText
        
    ;;

(**********************************************************************************************************************************************************************************************************************************)

    (* Sorts the letters by decreasing frequency order *)
    let sortByDecreasingFrequencies frequencies =
        
        let sortedLetters = ref [] in
        let initialSize = Hashtbl.length frequencies in
        while List.length !sortedLetters < initialSize
        do
            let maxFrequency = ref 0.0 in
            let maxLetter = ref ' ' in
            Hashtbl.iter
            (
                fun letter letterFrequency ->
                (
                    if letterFrequency > !maxFrequency
                    then
                    (
                        maxFrequency := letterFrequency;
                        maxLetter := letter
                    )
                )
            ) frequencies;
            Hashtbl.remove frequencies !maxLetter;
            sortedLetters := !sortedLetters @ [!maxLetter]
        done;
        !sortedLetters
        
    ;;

(**********************************************************************************************************************************************************************************************************************************)

    (* Determines the frequencies of the letters in the text, without the assumptions, to map the letters to the French ones *)
    let decodeMessage text sortedLettersInFrench =
        
        let frequenciesInText = determineFrequencies text in
        let sortedLettersInTextList = ref (sortByDecreasingFrequencies frequenciesInText) in
        let sortedLettersInFrenchList = ref sortedLettersInFrench in
        Hashtbl.iter
        (
            fun replacingLetter replacedLetter ->
            (
                let sortedLettersInTextArray = Array.of_list !sortedLettersInTextList in
                for i = 0 to Array.length sortedLettersInTextArray - 1
                do
                    if sortedLettersInTextArray.(i) = replacingLetter
                    then
                        sortedLettersInTextList := Array.to_list (Array.append (Array.sub sortedLettersInTextArray 0 i) (Array.sub sortedLettersInTextArray (i + 1) (Array.length sortedLettersInTextArray - 1 - i)))
                done;
                let sortedLettersInFrenchArray = Array.of_list !sortedLettersInFrenchList in
                for i = 0 to Array.length sortedLettersInFrenchArray - 1
                do
                    if sortedLettersInFrenchArray.(i) = replacedLetter
                    then
                        sortedLettersInFrenchList := Array.to_list (Array.append (Array.sub sortedLettersInFrenchArray 0 i) (Array.sub sortedLettersInFrenchArray (i + 1) (Array.length sortedLettersInFrenchArray - 1 - i)))
                done
            )
        ) assumedMappings;
        let sortedLettersInTextArray = Array.of_list !sortedLettersInTextList in
        let sortedLettersInFrenchArray = Array.of_list !sortedLettersInFrenchList in
        let mapping = Hashtbl.create 26 in
        for i = 0 to Array.length sortedLettersInTextArray - 1
        do
            Hashtbl.add mapping sortedLettersInTextArray.(i) sortedLettersInFrenchArray.(i)
        done;
        print_string "\027[31m[Encoded text] ";
        String.iter
        (
            fun letter ->
            (
                if Hashtbl.mem assumedMappings letter
                then
                    print_string "\027[32m"
                else
                    print_string "\027[0m"
                ;
                print_char letter
            )
        ) text;
        print_string "\n\027[31m[Decoded text] ";
        String.iter
        (
            fun letter ->
            (
                if Hashtbl.mem assumedMappings letter
                then
                (
                    print_string "\027[32m";
                    print_char (Hashtbl.find assumedMappings letter)
                )
                else
                (
                    print_string "\027[0m";
                    if Char.code letter >= Char.code 'a' && Char.code letter <= Char.code 'z'
                    then
                        print_char (Hashtbl.find mapping letter)
                    else
                        print_char letter
                )
            )
        ) text;
        print_endline "\027[0m";
        
    ;;

(**********************************************************************************************************************************************************************************************************************************)
(************************************************************************************************************ CONTROLS ************************************************************************************************************)
(**********************************************************************************************************************************************************************************************************************************)

    (* We check that there are enough arguments *)
    if Array.length Sys.argv <> 2
    then
        failwith ("Usage: ./code <image.png>")
    ;;

(**********************************************************************************************************************************************************************************************************************************)

    (* We check that the image exists *)
    if not (Sys.file_exists Sys.argv.(1))
    then
        failwith ("File " ^ Sys.argv.(1) ^ " doesn't exist")
    ;;

(**********************************************************************************************************************************************************************************************************************************)

    (* We check that the image is a .png file *)
    if String.compare (String.sub Sys.argv.(1) (String.length Sys.argv.(1) - 4) 4) ".png" <> 0
    then
        failwith ("File " ^ Sys.argv.(1) ^ " is not a .png file")
    ;;

(**********************************************************************************************************************************************************************************************************************************)
(************************************************************************************************************* SCRIPT *************************************************************************************************************)
(**********************************************************************************************************************************************************************************************************************************)

    (* Computation *)
    decodeMessage textToDecode sortedLettersInFrench;;
    let imageArray = loadImage Sys.argv.(1);;
    let resultArray = decodeImage imageArray;;
    
    (* To continue displaying the graphics *)
    while true do () done;;
    
(**********************************************************************************************************************************************************************************************************************************)
(**********************************************************************************************************************************************************************************************************************************)