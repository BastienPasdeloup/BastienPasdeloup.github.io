(**********************************************************************************************************************************************************************************************************************************)
(******************************************************************************************************** GLOBAL VARIABLES ********************************************************************************************************)
(**********************************************************************************************************************************************************************************************************************************)
    
    (* Constants *)
    let pi = 4.0 *. atan 1.0;;
    
    (* Initializations *)
    Random.self_init ();;
    
    (* For the plot *)
    let plotAsCircle = true;;
    let drawingAreaSize = 380;;
    let margin = 10;;
    let nodeSize = 3;;
    let defaultColor = Graphics.white;;
    
    (* For the result *)
    let color1 = Graphics.blue;;
    let color2 = Graphics.red;;
    let price1 = 0.86;;
    let price2 = 0.73;;
    
(**********************************************************************************************************************************************************************************************************************************)
(************************************************************************************************************ FUNCTIONS ***********************************************************************************************************)
(**********************************************************************************************************************************************************************************************************************************)
    
    (* Computes Graphviz coordinates for a given node *)
    let coordinatesToPlot nodes nodeIndex =
        
        (* If we plot the nodes in a circle *)
        if plotAsCircle then
            let graphOrder = Array.length nodes in
            let xCoordinate = cos (2.0 *. pi /. (float_of_int graphOrder) *. (float_of_int nodeIndex)) /. 2.0 +. 0.5 in
            let yCoordinate = sin (2.0 *. pi /. (float_of_int graphOrder) *. (float_of_int nodeIndex)) /. 2.0 +. 0.5 in
            (int_of_float (float_of_int margin +. float_of_int drawingAreaSize *. xCoordinate), int_of_float (float_of_int margin +. float_of_int drawingAreaSize *. yCoordinate))
        
        (* If we plot the normal coordinates *)
        else
            (int_of_float (float_of_int margin +. float_of_int drawingAreaSize *. fst nodes.(nodeIndex)), int_of_float (float_of_int margin +. float_of_int drawingAreaSize *. snd nodes.(nodeIndex)))
        
    ;;
    
(**********************************************************************************************************************************************************************************************************************************)

    (* Computes the Euclidean distance between nodes *)
    let euclideanDistance node1 node2 =
        
        (* Norm of the vector linking the nodes *)
        sqrt ((fst node1 -. fst node2) ** 2.0 +. (snd node1 -. snd node2) ** 2.0)
        
    ;;

(**********************************************************************************************************************************************************************************************************************************)

    (* Creates a random geometric graph and forces it to be bipartite *)
    let randomGeometricGraph graphOrder maxRadius =
        
        (* Random coordinates *)
        let nodes = Array.make graphOrder (0.0, 0.0) in
        for n = 0 to graphOrder - 1 do
            nodes.(n) <- (Random.float 1.0, Random.float 1.0)
        done;
        
        (* Random bipartite graph *)
        let setsForNodes = Array.make graphOrder 0 in
        let adjacencyMatrix = Array.make_matrix graphOrder graphOrder false in
        for l = 0 to graphOrder - 1 do
            for c = l + 1 to graphOrder - 1 do
                let distance = euclideanDistance nodes.(l) nodes.(c) in
                let notInSameSet = abs (setsForNodes.(l) + setsForNodes.(c)) <= 1 in
                if distance < maxRadius && notInSameSet then
                (
                    adjacencyMatrix.(l).(c) <- true;
                    adjacencyMatrix.(c).(l) <- true;
                    if setsForNodes.(l) = 0 && setsForNodes.(c) = 0 then
                    (
                        setsForNodes.(l) <- int_of_float ((-1.0) ** float_of_int (Random.int 2));
                        setsForNodes.(c) <- -setsForNodes.(l)
                    )
                    else if setsForNodes.(l) <> 0 then
                        setsForNodes.(c) <- -setsForNodes.(l)
                    else
                        setsForNodes.(l) <- -setsForNodes.(c)
                )
            done
        done;
        
        (* Result *)
        (nodes, adjacencyMatrix)
        
    ;;

(**********************************************************************************************************************************************************************************************************************************)

    (* Plots an edge of the graph *)
    let plotEdge nodes nodeIndex1 nodeIndex2 =
        
        (* We add it to the graphics *)
        Graphics.moveto (fst (coordinatesToPlot nodes nodeIndex1)) (snd (coordinatesToPlot nodes nodeIndex1));
        Graphics.lineto (fst (coordinatesToPlot nodes nodeIndex2)) (snd (coordinatesToPlot nodes nodeIndex2));
        
    ;;

(**********************************************************************************************************************************************************************************************************************************)

    (* Plots a node of the graph *)
    let plotNode nodes nodeIndex colorMap =
        
        (* We add it to the graphics *)
        Graphics.set_color colorMap.(nodeIndex);
        Graphics.fill_circle (fst (coordinatesToPlot nodes nodeIndex)) (snd (coordinatesToPlot nodes nodeIndex)) nodeSize;
        Graphics.set_color Graphics.black;
        Graphics.draw_circle (fst (coordinatesToPlot nodes nodeIndex)) (snd (coordinatesToPlot nodes nodeIndex)) nodeSize
        
    ;;
    
(**********************************************************************************************************************************************************************************************************************************)

    (* Plots a graph *)
    let plotGraph nodes adjacencyMatrix colorMap =
        
        (* We plot the edges *)
        let graphOrder = Array.length nodes in
        for l = 0 to graphOrder - 1 do
            for c = l + 1 to graphOrder - 1 do
                if adjacencyMatrix.(l).(c) then
                    plotEdge nodes l c
            done
        done;
        
        (* We add the nodes on top of it *)
        for n = 0 to graphOrder - 1 do
            plotNode nodes n colorMap
        done
        
    ;;

(**********************************************************************************************************************************************************************************************************************************)

    (* Sets up the window to display the graph *)
    let openGraphics () =
        
        (* We open the Graphics window *)
        Graphics.open_graph (" " ^ (string_of_int (drawingAreaSize + 2 * margin)) ^ "x" ^ (string_of_int (drawingAreaSize + 2 * margin)) ^ "+0-0")
        
    ;;

(**********************************************************************************************************************************************************************************************************************************)

    (* Creates an initial color map for the nodes *)
    let initialColorMap graphOrder =
        
        (* All nodes are initially drawn in white *)
        Array.make graphOrder defaultColor
        
    ;;

(**********************************************************************************************************************************************************************************************************************************)

    (* Writes the adjacency matrix to the shell *)
    let printMatrix adjacencyMatrix =
        
        (* We fill a string with a MATLAB-fashioned matrix *)
        let graphOrder = Array.length adjacencyMatrix in
        let stringToPrint = ref "[" in
        for l = 0 to graphOrder - 1 do
            for c = 0 to graphOrder - 1 do
                stringToPrint := !stringToPrint ^ (if adjacencyMatrix.(l).(c) then "1" else "0") ^ (if c <> graphOrder - 1 then " " else "")
            done;
            stringToPrint := !stringToPrint ^ (if l <> graphOrder - 1 then ";\n" else "]")
        done;
        
        (* Result *)
        print_endline !stringToPrint
        
    ;;

(**********************************************************************************************************************************************************************************************************************************)

    (* Creates a color map for the graph, with the a-priori knowledge that the graph is bipartite, and the assumption that it is connected *)
    let createColorMap adjacencyMatrix =
        
        (* Initialization *)
        let graphOrder = Array.length adjacencyMatrix in
        let colorMap = Array.make graphOrder defaultColor in
        colorMap.(0) <- color1;
        let coloredNodes = ref [0] in
        
        (* We color the neighbors of the newly colored nodes *)
        while List.length !coloredNodes > 0 do
            let node = List.hd !coloredNodes in
            for c = 0 to graphOrder - 1 do
                if adjacencyMatrix.(node).(c) && colorMap.(c) = defaultColor then
                (
                    colorMap.(c) <- if colorMap.(node) = color1 then color2 else color1;
                    coloredNodes := !coloredNodes @ [c]
                )
            done;
            coloredNodes := List.tl !coloredNodes
        done;
        
        (* Result *)
        colorMap
        
    ;;

(**********************************************************************************************************************************************************************************************************************************)

    (* Determines the minimum price to color the graph *)
    let determineMinimumPrice colorMap =
        
        (* We count the colors in the color map *)
        let counts = Array.make 2 0.0 in
        let graphOrder = Array.length colorMap in
        for node = 0 to graphOrder - 1 do
            if colorMap.(node) = color1 then
                counts.(0) <- counts.(0) +. 1.0
            else
                counts.(1) <- counts.(1) +. 1.0
        done;

        (* We determine the price *)
        (max counts.(0) counts.(1)) *. (min price1 price2) +. (min counts.(0) counts.(1)) *. (max price1 price2)
        
    ;;

(**********************************************************************************************************************************************************************************************************************************)

    (* Exports the graphics contents *)
    let exportGraphics fileName =
(*
let surface = Cairo.image_surface_create Cairo.FORMAT_ARGB32 400 400 in
let ctx = Cairo.create surface in

(* Set thickness of brush *)
Cairo.set_line_width ctx 15. ;

(* Draw out the triangle using absolute coordinates *)
Cairo.move_to     ctx   200.  100. ;
Cairo.line_to     ctx   300.  300. ;
Cairo.rel_line_to ctx (-200.)   0. ;
Cairo.close_path  ctx ;

(* Apply the ink *)
Cairo.stroke ctx ;

(* Output a PNG file *)
Cairo_png.surface_write_to_file surface "triangle.png"
*)
        ()
    ;;

(**********************************************************************************************************************************************************************************************************************************)
(************************************************************************************************************ CONTROLS ************************************************************************************************************)
(**********************************************************************************************************************************************************************************************************************************)

    (* We check that there are enough arguments *)
    if Array.length Sys.argv <> 4 then
        failwith ("Usage: ./code <graphOrder> <graphRadius> <outputDirectory>")
    ;;

(**********************************************************************************************************************************************************************************************************************************)

    (* We check that the graph has nodes *)
    if int_of_string Sys.argv.(1) < 1 then
        failwith ("Invalid graph order " ^ Sys.argv.(1))
    ;;

(**********************************************************************************************************************************************************************************************************************************)

    (* We check that the radius to create edges is not negative *)
    if float_of_string Sys.argv.(2) < 0.0 then
        failwith ("Invalid radius for graph generation " ^ Sys.argv.(2))
    ;;

(**********************************************************************************************************************************************************************************************************************************)

    (* We check that the output directory exists *)
    if not (Sys.file_exists Sys.argv.(3) && Sys.is_directory Sys.argv.(3))
    then
        failwith ("Output directory " ^ Sys.argv.(3) ^ " doesn't exist")
    ;;

(**********************************************************************************************************************************************************************************************************************************)
(************************************************************************************************************* SCRIPT *************************************************************************************************************)
(**********************************************************************************************************************************************************************************************************************************)

    (* Parameters *)
    let graphOrder = int_of_string Sys.argv.(1);;
    let graphRadius = float_of_string Sys.argv.(2);;
    let outputDirectory = Sys.argv.(3);;

    (* Initialization *)
    openGraphics ();;
    let (nodes, adjacencyMatrix) = randomGeometricGraph graphOrder graphRadius ;;
    plotGraph nodes adjacencyMatrix (initialColorMap graphOrder);;
    exportGraphics (outputDirectory ^ "/problem.png");;
    printMatrix adjacencyMatrix;;
    
    (* Resolution *)
    let resultColorMap = createColorMap adjacencyMatrix;;
(*
    plotGraph nodes adjacencyMatrix resultColorMap;;
*)
    exportGraphics (outputDirectory ^ "/solution.png");;
    print_endline ("Best price is " ^ string_of_float (determineMinimumPrice resultColorMap) ^ "€");;
    
    (* To continue displaying the graphics *)
    while true do () done;;
    
(**********************************************************************************************************************************************************************************************************************************)
(**********************************************************************************************************************************************************************************************************************************)